from birdpi.bootstrap import initialize
from birdpi.storage import Storage

config = initialize()
storage = Storage(config)

print("Before:", f"{storage.disk_usage()['free_percent']:.1f} %")

deleted = storage.cleanup_oldest_events()

print("Deleted events:", deleted)
print("After:", f"{storage.disk_usage()['free_percent']:.1f} %")
